/*
  Kotoba data loader
  Default source: jkindrix/japanese-language-data
  You can switch DATA_BASE below to your own GitHub repository after
  downloading/copying the data files.
*/

const DATA_BASE =
  "https://raw.githubusercontent.com/jkindrix/japanese-language-data/main/data";

const DATA_FILES = {
  kanji: `${DATA_BASE}/core/kanji.json`,
  words: `${DATA_BASE}/core/words.json`,
  radicals: `${DATA_BASE}/core/radicals.json`,
  sentences: `${DATA_BASE}/corpus/sentences.json`,
  grammar: `${DATA_BASE}/grammar/grammar.json`,
  conjugations: `${DATA_BASE}/grammar/conjugations.json`,
  jlpt: `${DATA_BASE}/enrichment/jlpt-classifications.json`,
  strokeIndex: `${DATA_BASE}/enrichment/stroke-order-index.json`
};

function unwrap(raw) {
  if (Array.isArray(raw)) return raw;
  if (!raw || typeof raw !== "object") return [];
  for (const key of ["data","items","entries","records","kanji","words","sentences","grammar"]) {
    if (Array.isArray(raw[key])) return raw[key];
  }
  return raw;
}

async function fetchJSON(url) {
  const response = await fetch(url, { cache: "force-cache" });
  if (!response.ok) throw new Error(`HTTP ${response.status}: ${url}`);
  return response.json();
}

export class DataLoader {
  constructor() {
    this.cache = new Map();
  }

  async get(name) {
    if (this.cache.has(name)) return this.cache.get(name);
    const url = DATA_FILES[name];
    if (!url) throw new Error(`Unknown dataset: ${name}`);
    const promise = fetchJSON(url).then(unwrap);
    this.cache.set(name, promise);
    return promise;
  }

  async loadCore() {
    const results = await Promise.allSettled([
      this.get("kanji"),
      this.get("words"),
      this.get("radicals"),
      this.get("sentences"),
      this.get("grammar"),
      this.get("conjugations"),
      this.get("jlpt"),
      this.get("strokeIndex")
    ]);

    const names = ["kanji","words","radicals","sentences","grammar","conjugations","jlpt","strokeIndex"];
    const data = {};
    results.forEach((r, i) => {
      data[names[i]] = r.status === "fulfilled" ? r.value : [];
    });

    return data;
  }

  async strokeSVG(character, strokeIndex) {
    let file = null;

    if (strokeIndex && typeof strokeIndex === "object" && !Array.isArray(strokeIndex)) {
      const hit = strokeIndex[character];
      if (typeof hit === "string") file = hit;
      else if (hit && typeof hit === "object") file = hit.svg || hit.file || hit.filename;
    }

    if (!file) {
      const cp = character.codePointAt(0).toString(16).padStart(5, "0").toLowerCase();
      file = `${cp}.svg`;
    }

    const candidates = [
      `${DATA_BASE}/enrichment/stroke-order/${file}`,
      `${DATA_BASE}/enrichment/stroke-order/${String(file).replace(/^.*[\\/]/,"")}`
    ];

    for (const url of candidates) {
      try {
        const r = await fetch(url, {cache:"force-cache"});
        if (r.ok) return await r.text();
      } catch (_) {}
    }
    return null;
  }
}

export { DATA_BASE, DATA_FILES };
